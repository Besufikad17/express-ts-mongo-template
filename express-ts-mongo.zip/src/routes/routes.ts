import { Router } from "express";

const route = Router();

export { route }